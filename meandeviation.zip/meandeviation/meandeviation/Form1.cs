﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace meandeviation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<double> mylist = new List<double>();
            foreach(string s in textBox1.Text.Split(","))
            {
                mylist.Add(double.Parse(s));
            }
            double average = mylist.Average();
            double meandeviation = mylist.Sum(d => Math.Abs(d - average)) / mylist.Count();
            MessageBox.Show("" + meandeviation);
        }
    }
}
